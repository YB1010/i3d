Student 1 name: BO YANG
Student 1 ID: s3623409

Student 2 name: Yuchen Yao
Student 2 ID:  s3548974